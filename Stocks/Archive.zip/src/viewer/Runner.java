package viewer;



  public class Runner {
    public static void main(String[] args) {
      if (args.length > 0 && args[0].equals("-text")) {
        TextViewer.main(new String[]{});
      } else {
        GUIViewer.main(new String[]{});
      }
    }
  }

